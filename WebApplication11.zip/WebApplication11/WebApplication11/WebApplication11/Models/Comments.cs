﻿using System;
using System.Collections.Generic;

namespace WebApplication11.Models
{
    public partial class Comments
    {
        public int CommentId { get; set; }
        public int? PostId { get; set; }
        public int? UserId { get; set; }
        public string Comment { get; set; }

        public Posts Post { get; set; }
        public UserInfo User { get; set; }
    }
}
